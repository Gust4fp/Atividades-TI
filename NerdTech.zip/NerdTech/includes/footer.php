</main>
<footer class="site-footer py-4 mt-5"><div class="container text-center text-secondary small">© <?= date('Y') ?> NerdTech — Projeto acadêmico de e-commerce.</div></footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>
</body></html>
