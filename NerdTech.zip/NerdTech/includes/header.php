<?php $user = currentUser(); ?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle ?? 'NerdTech') ?> | NerdTech</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="index.php">Nerd<span>Tech</span></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="menu">
      <div class="navbar-nav ms-auto align-items-lg-center">
        <a class="nav-link" href="index.php">Início</a>
        <a class="nav-link" href="index.php#produtos">Produtos</a>
        <a class="nav-link" href="carrinho.php">Carrinho (<?= array_sum($_SESSION['carrinho'] ?? []) ?>)</a>
        <?php if ($user): ?>
          <?php if ($user['tipo'] === 'admin'): ?><a class="nav-link" href="admin/index.php">Admin</a><?php endif; ?>
          <span class="nav-link text-secondary">Olá, <?= e($user['nome']) ?></span>
          <a class="nav-link" href="logout.php">Sair</a>
        <?php else: ?>
          <a class="nav-link" href="login.php">Entrar</a>
          <a class="btn btn-brand btn-sm ms-lg-2" href="cadastro.php">Criar conta</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
<main class="container py-4">
<?php if ($message = flash()): ?><div class="alert alert-info"><?= e($message) ?></div><?php endif; ?>
