<?php
function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}
function money($value): string {
    return 'R$ ' . number_format((float)$value, 2, ',', '.');
}
function redirect(string $url): never {
    header("Location: {$url}");
    exit;
}
function currentUser(): ?array {
    return $_SESSION['usuario'] ?? null;
}
function requireLogin(): void {
    if (!currentUser()) {
        $_SESSION['flash'] = 'Faça login para continuar.';
        redirect('login.php');
    }
}
function requireAdmin(): void {
    if (!currentUser() || currentUser()['tipo'] !== 'admin') {
        http_response_code(403);
        exit('Acesso permitido somente para administradores.');
    }
}
function flash(): ?string {
    $message = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $message;
}
