<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requireAdmin();
if($_SERVER['REQUEST_METHOD']==='POST'){
  $acao=$_POST['acao']??'';
  if($acao==='salvar'){
    $id=(int)($_POST['id']??0);$dados=[(int)$_POST['categoria_id'],trim($_POST['nome']),trim($_POST['descricao']),str_replace(',','.',$_POST['preco']), (int)$_POST['estoque'],trim($_POST['imagem'])];
    if($id){$dados[]=$id;$st=db()->prepare("UPDATE produtos SET categoria_id=?,nome=?,descricao=?,preco=?,estoque=?,imagem=? WHERE id=?");}
    else $st=db()->prepare("INSERT INTO produtos (categoria_id,nome,descricao,preco,estoque,imagem) VALUES (?,?,?,?,?,?)");
    $st->execute($dados);$_SESSION['flash']='Produto salvo.';redirect('index.php');
  }
  if($acao==='desativar'){$st=db()->prepare("UPDATE produtos SET ativo=0 WHERE id=?");$st->execute([(int)$_POST['id']]);$_SESSION['flash']='Produto desativado.';redirect('index.php');}
}
$cats=db()->query("SELECT id,nome FROM categorias ORDER BY nome")->fetchAll();
$products=db()->query("SELECT p.*,c.nome categoria FROM produtos p JOIN categorias c ON c.id=p.categoria_id ORDER BY p.id DESC")->fetchAll();
$orders=db()->query("SELECT p.id,p.data_pedido,p.total,p.forma_pagamento,u.nome cliente FROM pedidos p JOIN usuarios u ON u.id=p.usuario_id ORDER BY p.id DESC")->fetchAll();
$pageTitle='Administração';require __DIR__.'/../includes/header.php';
?>
<h1 class="section-title">Painel administrativo</h1>
<div class="row g-4 mt-1"><div class="col-lg-5"><div class="product-card p-3"><h2 class="h4">Cadastrar produto</h2><form method="post"><input type="hidden" name="acao" value="salvar"><label class="form-label">Categoria</label><select class="form-select mb-2" name="categoria_id" required><?php foreach($cats as $c): ?><option value="<?=$c['id']?>"><?=e($c['nome'])?></option><?php endforeach; ?></select><label class="form-label">Nome</label><input class="form-control mb-2" name="nome" required><label class="form-label">Descrição</label><textarea class="form-control mb-2" name="descricao"></textarea><label class="form-label">Preço</label><input class="form-control mb-2" name="preco" type="number" step="0.01" min="0" required><label class="form-label">Estoque</label><input class="form-control mb-2" name="estoque" type="number" min="0" required><label class="form-label">Caminho da imagem (opcional)</label><input class="form-control mb-3" name="imagem"><button class="btn btn-brand">Salvar produto</button></form></div></div>
<div class="col-lg-7"><h2 class="h4">Produtos</h2><div class="table-responsive"><table class="table"><tr><th>Produto</th><th>Preço</th><th>Estoque</th><th></th></tr><?php foreach($products as $p): ?><tr><td><?=e($p['nome'])?></td><td><?=money($p['preco'])?></td><td><?=$p['estoque']?></td><td><form method="post"><input type="hidden" name="acao" value="desativar"><input type="hidden" name="id" value="<?=$p['id']?>"><button class="btn btn-sm btn-outline-danger">Desativar</button></form></td></tr><?php endforeach; ?></table></div></div></div>
<h2 class="h4 mt-5">Pedidos realizados</h2><div class="table-responsive"><table class="table"><tr><th>Pedido</th><th>Cliente</th><th>Data</th><th>Pagamento</th><th>Total</th></tr><?php foreach($orders as $o): ?><tr><td>#<?=$o['id']?></td><td><?=e($o['cliente'])?></td><td><?=e($o['data_pedido'])?></td><td><?=e($o['forma_pagamento'])?></td><td><?=money($o['total'])?></td></tr><?php endforeach; ?></table></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
