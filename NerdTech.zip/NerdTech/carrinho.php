<?php
require_once __DIR__ . '/includes/bootstrap.php';
$_SESSION['carrinho'] ??= [];
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $acao=$_POST['acao']??''; $id=(int)($_POST['produto_id']??0);
  if ($acao==='adicionar' && $id>0) {
    $stmt=db()->prepare("SELECT estoque FROM produtos WHERE id=? AND ativo=1"); $stmt->execute([$id]); $p=$stmt->fetch();
    if ($p && $p['estoque']>0) { $_SESSION['carrinho'][$id]=min(($_SESSION['carrinho'][$id]??0)+1,(int)$p['estoque']); $_SESSION['flash']='Produto adicionado ao carrinho.'; }
  } elseif ($acao==='remover') unset($_SESSION['carrinho'][$id]);
  elseif ($acao==='atualizar') foreach (($_POST['quantidade']??[]) as $pid=>$q) { $pid=(int)$pid;$q=max(0,(int)$q);$st=db()->prepare("SELECT estoque FROM produtos WHERE id=?");$st->execute([$pid]);$p=$st->fetch(); if(!$q)unset($_SESSION['carrinho'][$pid]);elseif($p)$_SESSION['carrinho'][$pid]=min($q,(int)$p['estoque']); }
  redirect('carrinho.php');
}
$items=[];$total=0;
if ($_SESSION['carrinho']) {
  $ids=array_keys($_SESSION['carrinho']); $marks=implode(',',array_fill(0,count($ids),'?'));
  $st=db()->prepare("SELECT id,nome,preco,estoque FROM produtos WHERE id IN ($marks) AND ativo=1");$st->execute($ids);
  foreach($st->fetchAll() as $p){$p['quantidade']=$_SESSION['carrinho'][$p['id']];$p['subtotal']=$p['preco']*$p['quantidade'];$total+=$p['subtotal'];$items[]=$p;}
}
$pageTitle='Carrinho';require __DIR__.'/includes/header.php';
?>
<h1 class="section-title mb-4">Meu carrinho</h1>
<?php if(!$items): ?><p class="text-secondary">Seu carrinho está vazio.</p><a class="btn btn-brand" href="index.php">Ver produtos</a><?php else: ?>
<form method="post"><input type="hidden" name="acao" value="atualizar"><div class="table-responsive"><table class="table align-middle"><thead><tr><th>Produto</th><th>Preço</th><th>Quantidade</th><th>Subtotal</th><th></th></tr></thead><tbody>
<?php foreach($items as $p): ?><tr><td><?=e($p['nome'])?></td><td><?=money($p['preco'])?></td><td><input class="form-control" style="max-width:90px" type="number" min="0" max="<?= (int)$p['estoque'] ?>" name="quantidade[<?= (int)$p['id'] ?>]" value="<?= (int)$p['quantidade'] ?>"></td><td><?=money($p['subtotal'])?></td><td><button class="btn btn-sm btn-outline-danger" formaction="carrinho.php" formmethod="post" name="acao" value="remover" onclick="this.form.insertAdjacentHTML('beforeend','<input type=hidden name=produto_id value=<?= (int)$p['id'] ?>>')">Remover</button></td></tr><?php endforeach; ?>
</tbody></table></div><button class="btn btn-outline-light">Atualizar quantidades</button></form>
<div class="text-end mt-4"><h3>Total: <span class="price"><?=money($total)?></span></h3><a class="btn btn-brand" href="checkout.php">Continuar para checkout</a></div>
<?php endif; require __DIR__.'/includes/footer.php'; ?>
