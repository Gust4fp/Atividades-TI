// Arquivo reservado para interações do front-end da NerdTech.
document.addEventListener('DOMContentLoaded', () => {
  console.log('NerdTech carregada.');
});
