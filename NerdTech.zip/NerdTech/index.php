<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Início';
$search = trim($_GET['q'] ?? '');
$categoryId = (int)($_GET['categoria'] ?? 0);

$sql = "SELECT p.*, c.nome AS categoria_nome FROM produtos p
        INNER JOIN categorias c ON c.id = p.categoria_id
        WHERE p.ativo = 1";
$params = [];
if ($search !== '') {
    $sql .= " AND (p.nome LIKE :q OR p.descricao LIKE :q)";
    $params['q'] = "%{$search}%";
}
if ($categoryId > 0) {
    $sql .= " AND p.categoria_id = :categoria";
    $params['categoria'] = $categoryId;
}
$sql .= " ORDER BY p.criado_em DESC";
$stmt = db()->prepare($sql);
$stmt->execute($params);
$produtos = $stmt->fetchAll();
$categorias = db()->query("SELECT id, nome FROM categorias ORDER BY nome")->fetchAll();
require __DIR__ . '/includes/header.php';
?>
<section class="hero rounded-4 p-4 p-md-5 mb-4">
  <div class="row align-items-center">
    <div class="col-lg-8">
      <span class="eyebrow">TECNOLOGIA PARA QUEM VAI ALÉM</span>
      <h1 class="display-4 fw-bold mt-3">ELEVE SEU <span>GAME.</span></h1>
      <p class="lead text-secondary">Periféricos e equipamentos para montar seu setup do seu jeito.</p>
      <a class="btn btn-brand btn-lg mt-2" href="#produtos">Explorar produtos</a>
    </div>
    <div class="col-lg-4 d-none d-lg-block text-center hero-mark">NT<span>.</span></div>
  </div>
</section>

<section id="produtos">
  <div class="d-flex flex-wrap justify-content-between align-items-end gap-3 mb-3">
    <div><span class="eyebrow">NOSSA VITRINE</span><h2 class="section-title mb-0">Produtos em destaque</h2></div>
    <form class="d-flex gap-2" method="get">
      <input class="form-control" type="search" name="q" placeholder="Buscar produto..." value="<?= e($search) ?>">
      <select class="form-select" name="categoria">
        <option value="0">Todas categorias</option>
        <?php foreach ($categorias as $cat): ?>
          <option value="<?= (int)$cat['id'] ?>" <?= $categoryId === (int)$cat['id'] ? 'selected' : '' ?>><?= e($cat['nome']) ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn btn-outline-light">Buscar</button>
    </form>
  </div>
  <div class="row g-3">
    <?php if (!$produtos): ?><p class="text-secondary">Nenhum produto encontrado. Cadastre produtos pelo painel administrativo.</p><?php endif; ?>
    <?php foreach ($produtos as $produto): ?>
      <div class="col-sm-6 col-lg-4 col-xl-3">
        <article class="product-card h-100">
          <div class="product-image">
            <?php if (!empty($produto['imagem'])): ?><img src="<?= e($produto['imagem']) ?>" alt="<?= e($produto['nome']) ?>">
            <?php else: ?><span>NERD<span class="accent">TECH</span></span><?php endif; ?>
          </div>
          <div class="p-3">
            <small class="text-secondary"><?= e($produto['categoria_nome']) ?></small>
            <h3 class="h5 mt-1"><?= e($produto['nome']) ?></h3>
            <p class="text-secondary small"><?= e(mb_strimwidth($produto['descricao'] ?? '', 0, 85, '...')) ?></p>
            <div class="d-flex justify-content-between align-items-center">
              <strong class="price"><?= money($produto['preco']) ?></strong>
              <a class="btn btn-sm btn-brand" href="produto.php?id=<?= (int)$produto['id'] ?>">Ver produto</a>
            </div>
            <small class="d-block mt-2 text-secondary"><?= (int)$produto['estoque'] > 0 ? 'Em estoque' : 'Indisponível' ?></small>
          </div>
        </article>
      </div>
    <?php endforeach; ?>
  </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
