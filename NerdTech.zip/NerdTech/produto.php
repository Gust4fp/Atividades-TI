<?php
require_once __DIR__ . '/includes/bootstrap.php';
$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("SELECT p.*, c.nome AS categoria_nome FROM produtos p JOIN categorias c ON c.id=p.categoria_id WHERE p.id=? AND p.ativo=1");
$stmt->execute([$id]);
$produto = $stmt->fetch();
if (!$produto) { http_response_code(404); exit('Produto não encontrado.'); }
$pageTitle = $produto['nome'];
require __DIR__ . '/includes/header.php';
?>
<div class="row g-4">
  <div class="col-md-6"><div class="product-image rounded-4" style="height:360px"><?php if ($produto['imagem']): ?><img src="<?= e($produto['imagem']) ?>" alt="<?= e($produto['nome']) ?>"><?php else: ?>NERDTECH<?php endif; ?></div></div>
  <div class="col-md-6"><span class="eyebrow"><?= e($produto['categoria_nome']) ?></span><h1 class="mt-2"><?= e($produto['nome']) ?></h1><p class="text-secondary"><?= nl2br(e($produto['descricao'])) ?></p><h2 class="price"><?= money($produto['preco']) ?></h2><p><?= (int)$produto['estoque'] > 0 ? 'Estoque disponível: '.(int)$produto['estoque'] : 'Produto indisponível' ?></p>
  <?php if ((int)$produto['estoque'] > 0): ?><form method="post" action="carrinho.php"><input type="hidden" name="acao" value="adicionar"><input type="hidden" name="produto_id" value="<?= (int)$produto['id'] ?>"><button class="btn btn-brand">Adicionar ao carrinho</button></form><?php endif; ?>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
