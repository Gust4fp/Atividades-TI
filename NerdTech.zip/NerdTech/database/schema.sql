CREATE DATABASE IF NOT EXISTS nerdtech CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nerdtech;

CREATE TABLE IF NOT EXISTS usuarios (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 senha VARCHAR(255) NOT NULL,
 tipo ENUM('cliente','admin') NOT NULL DEFAULT 'cliente',
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categorias (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nome VARCHAR(100) NOT NULL,
 descricao TEXT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS produtos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 categoria_id INT NOT NULL,
 nome VARCHAR(150) NOT NULL,
 descricao TEXT,
 preco DECIMAL(10,2) NOT NULL,
 estoque INT NOT NULL DEFAULT 0,
 imagem VARCHAR(255),
 ativo TINYINT(1) NOT NULL DEFAULT 1,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_produto_categoria FOREIGN KEY (categoria_id) REFERENCES categorias(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pedidos (
 id INT AUTO_INCREMENT PRIMARY KEY,
 usuario_id INT NOT NULL,
 data_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 forma_pagamento ENUM('PIX','Boleto','Cartao') NOT NULL,
 total DECIMAL(10,2) NOT NULL,
 status VARCHAR(30) DEFAULT 'Confirmado',
 CONSTRAINT fk_pedido_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS itens_pedido (
 id INT AUTO_INCREMENT PRIMARY KEY,
 pedido_id INT NOT NULL,
 produto_id INT NOT NULL,
 quantidade INT NOT NULL,
 preco_unitario DECIMAL(10,2) NOT NULL,
 CONSTRAINT fk_item_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
 CONSTRAINT fk_item_produto FOREIGN KEY (produto_id) REFERENCES produtos(id)
) ENGINE=InnoDB;

INSERT INTO categorias (nome,descricao) VALUES
('Teclados','Teclados mecânicos e gamer'),
('Mouses','Mouses gamer e acessórios'),
('Headsets','Headsets e áudio'),
('Monitores','Monitores para jogos')
ON DUPLICATE KEY UPDATE nome=VALUES(nome);
