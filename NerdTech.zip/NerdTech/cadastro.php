<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle='Criar conta';
$erro='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $nome=trim($_POST['nome']??''); $email=trim($_POST['email']??''); $senha=$_POST['senha']??'';
  if ($nome==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($senha)<8) $erro='Preencha os campos corretamente. A senha deve ter pelo menos 8 caracteres.';
  else {
    try {
      $stmt=db()->prepare("INSERT INTO usuarios (nome,email,senha) VALUES (:nome,:email,:senha)");
      $stmt->execute(['nome'=>$nome,'email'=>$email,'senha'=>password_hash($senha,PASSWORD_DEFAULT)]);
      $_SESSION['flash']='Conta criada! Faça login.';
      redirect('login.php');
    } catch (PDOException $e) { $erro='Não foi possível criar a conta. Talvez esse e-mail já esteja cadastrado.'; }
  }
}
require __DIR__.'/includes/header.php';
?>
<div class="auth-card"><h1 class="h3 mb-3">Criar conta</h1><?php if($erro): ?><div class="alert alert-danger"><?=e($erro)?></div><?php endif; ?>
<form method="post"><label class="form-label">Nome</label><input class="form-control mb-3" name="nome" required maxlength="100"><label class="form-label">E-mail</label><input class="form-control mb-3" type="email" name="email" required><label class="form-label">Senha (mínimo 8 caracteres)</label><input class="form-control mb-3" type="password" name="senha" minlength="8" required><button class="btn btn-brand w-100">Cadastrar</button></form></div>
<?php require __DIR__.'/includes/footer.php'; ?>
