<?php
require_once __DIR__ . '/includes/bootstrap.php';
requireLogin();
$cart=$_SESSION['carrinho']??[]; if(!$cart){$_SESSION['flash']='Seu carrinho está vazio.';redirect('carrinho.php');}
$erro='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $forma=$_POST['forma_pagamento']??'';
  if(!in_array($forma,['PIX','Boleto','Cartao'],true))$erro='Selecione uma forma de pagamento válida.';
  else {
    try {
      $pdo=db();$pdo->beginTransaction();$total=0;$rows=[];
      foreach($cart as $id=>$qty){$st=$pdo->prepare("SELECT id,nome,preco,estoque FROM produtos WHERE id=? AND ativo=1 FOR UPDATE");$st->execute([(int)$id]);$p=$st->fetch();if(!$p||(int)$p['estoque']<(int)$qty)throw new RuntimeException('Estoque insuficiente para um dos produtos.');$total+=(float)$p['preco']*(int)$qty;$rows[]=[$p,(int)$qty];}
      $st=$pdo->prepare("INSERT INTO pedidos (usuario_id,forma_pagamento,total) VALUES (?,?,?)");$st->execute([currentUser()['id'],$forma,$total]);$pedidoId=(int)$pdo->lastInsertId();
      foreach($rows as [$p,$qty]){$st=$pdo->prepare("INSERT INTO itens_pedido (pedido_id,produto_id,quantidade,preco_unitario) VALUES (?,?,?,?)");$st->execute([$pedidoId,$p['id'],$qty,$p['preco']]);$st=$pdo->prepare("UPDATE produtos SET estoque=estoque-? WHERE id=?");$st->execute([$qty,$p['id']]);}
      $pdo->commit();unset($_SESSION['carrinho']);$_SESSION['flash']="Pedido #{$pedidoId} confirmado! Pagamento simulado.";redirect('index.php');
    } catch(Throwable $e){if(db()->inTransaction())db()->rollBack();$erro=$e instanceof RuntimeException?$e->getMessage():'Não foi possível finalizar o pedido.';}
  }
}
$pageTitle='Checkout';require __DIR__.'/includes/header.php';
?>
<div class="auth-card"><h1 class="h3">Finalizar compra</h1><p class="text-secondary">Escolha uma forma de pagamento. Esta etapa é uma simulação acadêmica; nenhum pagamento real será realizado.</p><?php if($erro): ?><div class="alert alert-danger"><?=e($erro)?></div><?php endif; ?><form method="post"><label class="form-label">Forma de pagamento</label><select class="form-select mb-3" name="forma_pagamento" required><option value="">Selecione...</option><option value="PIX">PIX</option><option value="Boleto">Boleto</option><option value="Cartao">Cartão</option></select><button class="btn btn-brand w-100">Confirmar pedido</button></form></div>
<?php require __DIR__.'/includes/footer.php'; ?>
