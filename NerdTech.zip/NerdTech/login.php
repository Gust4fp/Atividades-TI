<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle='Entrar'; $erro='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $stmt=db()->prepare("SELECT id,nome,email,senha,tipo FROM usuarios WHERE email=?");
  $stmt->execute([trim($_POST['email']??'')]); $user=$stmt->fetch();
  if ($user && password_verify($_POST['senha']??'', $user['senha'])) {
    session_regenerate_id(true); unset($user['senha']); $_SESSION['usuario']=$user; redirect('index.php');
  } else $erro='E-mail ou senha inválidos.';
}
require __DIR__.'/includes/header.php';
?>
<div class="auth-card"><h1 class="h3 mb-3">Entrar na NerdTech</h1><?php if($erro): ?><div class="alert alert-danger"><?=e($erro)?></div><?php endif; ?>
<form method="post"><label class="form-label">E-mail</label><input class="form-control mb-3" type="email" name="email" required><label class="form-label">Senha</label><input class="form-control mb-3" type="password" name="senha" required><button class="btn btn-brand w-100">Entrar</button></form><p class="mt-3 mb-0 text-secondary">Ainda não tem conta? <a href="cadastro.php">Cadastre-se</a>.</p></div>
<?php require __DIR__.'/includes/footer.php'; ?>
